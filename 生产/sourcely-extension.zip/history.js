// ===== Sourcely — 历史记录页 =====
// MV3 标准：通过 lib/api.js 委托所有网络请求。

var HistoryPage = (function () {
  'use strict';

  var _items = [];
  var _selected = {};  // {offer_id: true} 对比勾选状态
  var _maxItems = 20;  // 历史记录上限（从 /api/quota 的 history_max 动态获取，默认 free=20）

  function getEls() {
    return {
      search: document.getElementById('historySearch'),
      list: document.getElementById('historyList'),
      counter: document.getElementById('historyCounter')
    };
  }

  function escHtml(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function formatTime(isoStr) {
    if (!isoStr) return '';
    var d = new Date(isoStr);
    if (isNaN(d.getTime())) return '';
    var now = new Date();
    var diff = now - d;
    if (diff < 60000) return I18N.t('history.timeJustNow') || '刚刚';
    if (diff < 3600000) return (I18N.t('history.timeMinutesAgo') || '{n} 分钟前').replace('{n}', Math.floor(diff/60000));
    if (diff < 86400000) return (I18N.t('history.timeHoursAgo') || '{n} 小时前').replace('{n}', Math.floor(diff/3600000));
    if (diff < 604800000) return (I18N.t('history.timeDaysAgo') || '{n} 天前').replace('{n}', Math.floor(diff/86400000));
    return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  }

  function load() {
    // 先拿 history_max（paid=100/free=20），失败用默认值，不阻塞列表加载
    API.getQuota().then(function (qres) {
      if (qres && qres.code === 200 && qres.data && qres.data.history_max) {
        _maxItems = qres.data.history_max;
      }
    }).catch(function () {
      // 拿不到 history_max 就用默认 _maxItems，继续拉列表
    }).then(function () {
      return API.getHistory(1, _maxItems);
    }).then(function (res) {
      if (!res || res.code !== 200) {
        var els = getEls();
        els.list.innerHTML = '<div class="empty-state"><div class="empty-icon">⚠️</div><p>' + (I18N.t('history.loadFailed') || '加载失败') + '</p></div>';
        return;
      }
      _items = (res.data && res.data.items) ? res.data.items : [];
      renderList(_items);
    }).catch(function () {
      var els = getEls();
      els.list.innerHTML = '<div class="empty-state"><div class="empty-icon">⚠️</div><p>' + (I18N.t('history.loadFailed') || '加载失败') + '</p></div>';
    });
  }

  function confirmDelete(item) {
    var overlay = document.createElement('div');
    overlay.className = 'confirm-overlay';
    overlay.innerHTML = '<div class="confirm-dialog">' +
      '<p class="confirm-text">' + (I18N.t('history.deleteConfirm') || '确定删除这条记录？') + '</p>' +
      '<div class="confirm-actions">' +
        '<button class="confirm-btn confirm-btn-no">' + (I18N.t('history.cancel') || '取消') + '</button>' +
        '<button class="confirm-btn confirm-btn-yes">' + (I18N.t('history.delete') || '删除') + '</button>' +
      '</div></div>';
    document.body.appendChild(overlay);

    overlay.querySelector('.confirm-btn-no').addEventListener('click', function () {
      overlay.remove();
    });
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) overlay.remove();
    });

    overlay.querySelector('.confirm-btn-yes').addEventListener('click', function () {
      overlay.querySelector('.confirm-btn-yes').disabled = true;
      API.deleteHistory(item.analysis_id || item.id).then(function (res) {
        overlay.remove();
        if (res && res.code === 200) {
          load();
        } else {
          var els = getEls();
          els.list.insertAdjacentHTML('afterbegin',
            '<div class="empty-state" style="padding:12px;"><div class="empty-icon">⚠️</div><p>' +
            escHtml(I18N.msg(res && res.msg_code, res && res.message) || I18N.t('history.deleteFailed') || '删除失败') + '</p></div>');
        }
      }).catch(function () {
        overlay.remove();
      });
    });
  }

  function renderList(items) {
    var els = getEls();
    if (!items || items.length === 0) {
      els.list.innerHTML = '<div class="empty-state"><div class="empty-icon">📋</div><p>' +
        (I18N.t('history.empty') || '暂无历史记录') + '</p></div>';
      if (els.counter) els.counter.style.display = 'none';
      return;
    }

    // 计数器
    var total = String(items.length);
    var MAX = _maxItems;  // 从 /api/quota 的 history_max 动态获取
    if (els.counter) {
      els.counter.style.display = 'block';
      els.counter.textContent = total + '/' + MAX;
      els.counter.className = 'history-counter' + (items.length >= MAX ? ' full' : '');
    }

    var html = '';
    items.forEach(function (item) {
      var thumb = item.image_url || '';
      var title = item.title || item.offer_id || '';
      var time = formatTime(item.created_at);
      var grade = item.seller_grade || 'none';  // 后端 evaluate_supplier 算好的四档，不再正则匹配文本
      var gradeEmoji = { go:'🟢', ok:'🟡', bad:'🔴', none:'⬜' };
      var favOn = item.favorited;

      var oid = String(item.offer_id || '');
      html += '<div class="history-item" data-offer-id="' + escHtml(oid) + '">';
      html += '<input type="checkbox" class="history-item-check" data-offer-id="' + escHtml(oid) + '"' + (_selected[oid] ? ' checked' : '') + '>';
      if (thumb) {
        html += '<img class="history-item-thumb" src="' + escHtml(thumb) +
                '" alt="" referrerpolicy="no-referrer" loading="lazy" onerror="this.style.display=\'none\'">';
      } else {
        html += '<div class="history-item-thumb" style="display:flex;align-items:center;justify-content:center;color:#9ca3af;">📦</div>';
      }
      html += '<div class="history-item-info">' +
              '<div class="history-item-title">' + escHtml(title) + '</div>' +
              '<div class="history-item-time">' + escHtml(time) + '</div>' +
              '</div>';
      html += '<span class="history-item-grade ' + grade + '">' + (gradeEmoji[grade] || '⬜') + '</span>';
      html += '<button class="history-item-fav' + (favOn ? ' on' : '') + '" data-id="' + escHtml(String(item.analysis_id || item.id || '')) + '" title="' + (I18N.t('history.favorite') || '收藏') + '">' + (favOn ? '⭐' : '☆') + '</button>';
      html += '<button class="history-item-del" data-id="' + escHtml(String(item.analysis_id || item.id || '')) + '" title="' + (I18N.t('history.delete') || '删除') + '">×</button>';
      html += '</div>';
    });

    // 上限提醒（≥18条时显示）
    if (items.length >= 18) {
      var left = MAX - items.length;
      var favHtml = '<b>' + (I18N.t('history.favorite') || '收藏') + '</b>';
      html += '<div class="limit-warning">' +
        (left > 0
          ? (I18N.t('history.limitAlmostFull') || '📌 还差 {n} 条就满了。{fav}重要记录防止自动清除。').replace('{n}', left).replace('{fav}', favHtml)
          : (I18N.t('history.limitFull') || '⚠️ 已达上限。新分析将自动清除最早的未收藏记录。{fav}可防删。').replace('{fav}', favHtml)) +
        '</div>';
    }

    els.list.innerHTML = html;

    // 复选框 — 阻止冒泡（不触发 item 点击跳转报告）
    els.list.querySelectorAll('.history-item-check').forEach(function (cb) {
      cb.addEventListener('click', function (e) {
        e.stopPropagation();
        var oid = cb.getAttribute('data-offer-id');
        if (cb.checked) {
          // 最多 3 个
          var cnt = Object.keys(_selected).filter(function (k) { return _selected[k]; }).length;
          if (cnt >= 3) {
            cb.checked = false;
            Toast.show(I18N.t('compare.maxHint') || '最多选择 3 个商品进行对比', 'warning');
            return;
          }
          _selected[oid] = true;
        } else {
          _selected[oid] = false;
        }
        updateCompareBar();
      });
    });

    // item 点击 → 跳转报告（点复选框不触发）
    els.list.querySelectorAll('.history-item').forEach(function (el) {
      el.addEventListener('click', function (e) {
        // 不拦截复选框
        if (e.target.tagName === 'INPUT') return;
        var offerId = el.getAttribute('data-offer-id');
        if (offerId) switchToReport(offerId);
      });
    });

    // 收藏按钮 — 阻止冒泡防止触发 item 点击
    els.list.querySelectorAll('.history-item-fav').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = btn.getAttribute('data-id');
        API.toggleFavorite(parseInt(id, 10)).then(function (res) {
          if (res && res.code === 200 && res.data) {
            var newState = res.data.favorited;
            btn.textContent = newState ? '⭐' : '☆';
            btn.className = 'history-item-fav' + (newState ? ' on' : '');
          }
        });
      });
    });

    // 删除按钮 — 阻止冒泡防止触发 item 点击
    els.list.querySelectorAll('.history-item-del').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = btn.getAttribute('data-id');
        var found = null;
        (_items || []).forEach(function (it) {
          if (String(it.analysis_id || it.id || '') === id) found = it;
        });
        if (found) confirmDelete(found);
      });
    });
  }

  function switchToReport(offerId) {
    document.querySelectorAll('.tab-btn').forEach(function (btn) {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === 'report');
    });
    document.getElementById('tab-report').classList.add('active');
    document.getElementById('tab-history').classList.remove('active');

    // 目标语言可能未生成（切换语言后），请求期间先清空旧内容显示加载，避免旧语言报告残留
    if (typeof window._showReportLoading === 'function') window._showReportLoading();

    API.getReport(offerId, I18N.getLang()).then(function (res) {
      if (res && res.code === 200 && res.data && res.data.result) {
        if (typeof window._renderReport === 'function') {
          window._renderReport(res.data.result);
        }
      }
    });
  }

  // ====================================================================
  // 对比功能
  // ====================================================================

  function updateCompareBar() {
    var bar = document.getElementById('compareBar');
    var btn = document.getElementById('btnCompare');
    if (!bar || !btn) return;
    var ids = Object.keys(_selected).filter(function (k) { return _selected[k]; });
    if (ids.length >= 2) {
      bar.style.display = 'flex';
      btn.textContent = (I18N.t('compare.btn') || '对比') + ' (' + ids.length + ')';
      btn.disabled = false;
    } else {
      bar.style.display = 'none';
    }
  }

  function showCompareModal(ids) {
    var modal = document.getElementById('compareModal');
    if (!modal) return;
    // 并行拉取 report
    var promises = ids.map(function (oid) {
      return API.getReport(oid, I18N.getLang()).then(function (res) {
        if (res && res.code === 200 && res.data && res.data.result) {
          return { offerId: oid, display: res.data.result.display || res.data.result };
        }
        return { offerId: oid, display: null };
      }).catch(function () {
        return { offerId: oid, display: null };
      });
    });
    Promise.all(promises).then(function (results) {
      renderCompareTable(results);
      modal.style.display = 'flex';
    });
  }

  function hideCompareModal() {
    var modal = document.getElementById('compareModal');
    if (modal) modal.style.display = 'none';
  }

  function renderCompareTable(results) {
    var wrap = document.getElementById('compareTableWrap');
    if (!wrap) return;

    // 每行对比项：{label, extract(display)}
    var ROWS = [
      { label: I18N.t('compare.conclusion') || '结论', fn: function (d) { return _extractVerdict(d); }, isHtml: true },
      { label: I18N.t('compare.price') || '价格',    fn: function (d) { return d && d.price ? (d.price.low || 0) + '-' + (d.price.high || 0) : '-'; } },
      { label: I18N.t('compare.moq') || '起批',      fn: function (d) { return d && d.price && d.price.moq ? d.price.moq + ' ' + (I18N.t('inspect.piecesUnit') || '件') : '-'; } },
      { label: I18N.t('compare.product') || '产品评分', fn: function (d) { return d && d.productEval ? (d.productEval.grade || '') + ' ' + (d.productEval.score || 0) + '/' + (d.productEval.max_score || 18) : '-'; } },
      { label: I18N.t('compare.supplier') || '供应商评分', fn: function (d) { return d && d.supplierEval ? (d.supplierEval.grade || '') + ' ' + (d.supplierEval.score || 0) + '/' + (d.supplierEval.max_score || 9) : '-'; } },
      { label: '',                                     fn: function (d) { return _extractSupplierMeta(d); }, isHtml: true },
      { label: I18N.t('compare.sales') || '销量',      fn: function (d) { return d && d.sales && d.sales.sold ? d.sales.sold : '-'; } },
      { label: I18N.t('compare.stock') || '库存',      fn: function (d) { return d && d.productEval && d.productEval.stockLevel ? d.productEval.stockLevel.text : '-'; } }
    ];

    // 标题行
    var html = '<table class="compare-table"><thead><tr><th></th>';
    results.forEach(function (r) {
      var title = r.display && r.display.title ? r.display.title : r.offerId;
      var img = r.display && r.display.images && r.display.images[0] ? r.display.images[0] : '';
      html += '<th><div class="cmp-title" title="' + escHtml(title) + '">';
      if (img) html += '<img class="cmp-img" src="' + escHtml(img) + '" alt="">';
      html += '<span class="cmp-title-text">' + escHtml(String(title).slice(0, 16)) + '</span>';
      html += '</div></th>';
    });
    html += '</tr></thead><tbody>';

    // 数据行
    ROWS.forEach(function (row, ri) {
      html += '<tr>';
      html += '<td>' + escHtml(row.label) + '</td>';
      results.forEach(function (r, ci) {
        var val = row.fn(r.display);
        if (row.isHtml) {
          html += '<td>' + val + '</td>';
        } else {
          html += '<td>' + escHtml(String(val)) + '</td>';
        }
      });
      html += '</tr>';
    });

    html += '</tbody></table>';
    wrap.innerHTML = html;
  }

  // 从 display 提取供应商身份标签（类型/认证/年限）
  function _extractSupplierMeta(d) {
    if (!d) return '<span class="cmp-identity">-</span>';
    var parts = [];
    // 身份类型
    var label = d.trustBar && d.trustBar.label ? d.trustBar.label : '';
    if (label) parts.push(label);
    // 认证 + 年限 从 supplierEval dimensions 取
    var dims = d.supplierEval && d.supplierEval.dimensions ? d.supplierEval.dimensions : [];
    dims.forEach(function (dim) {
      if (dim.key === 'd2' && dim.data) parts.push(dim.data);  // 认证
      if (dim.key === 'd3' && dim.data) parts.push(dim.data);  // 年限
    });
    var text = parts.length ? parts.join(' · ') : '-';
    return '<span class="cmp-identity">' + escHtml(text) + '</span>';
  }

  // 综合结论档位（4 档颜色 + 短结论；none 显式标「-」防误导）
  function _extractVerdict(d) {
    if (!d || !d.summaryLine) return '<span class="cmp-grade cmp-grade-none">⬜ -</span>';
    var s = d.summaryLine;
    var emoji = { go: '🟢', ok: '🟡', bad: '🔴', none: '⬜' }[s.grade] || '⬜';
    var label = s.short || '-';
    return '<span class="cmp-grade cmp-grade-' + escHtml(s.grade || 'none') + '">' + emoji + ' ' + escHtml(label) + '</span>';
  }

  function initCompare() {
    var bar = document.getElementById('compareBar');
    var btn = document.getElementById('btnCompare');
    var closeBtn = document.getElementById('compareCloseBtn');
    var backBtn = document.getElementById('compareBackBtn');

    if (btn) {
      btn.addEventListener('click', function () {
        var ids = Object.keys(_selected).filter(function (k) { return _selected[k]; });
        if (ids.length < 2) return;
        showCompareModal(ids);
      });
    }

    if (closeBtn) {
      closeBtn.addEventListener('click', hideCompareModal);
    }
    if (backBtn) {
      backBtn.addEventListener('click', hideCompareModal);
    }
  }

  function initSearch() {
    var els = getEls();
    if (!els.search) return;
    els.search.addEventListener('input', function () {
      var q = els.search.value.trim().toLowerCase();
      if (!q) { renderList(_items); return; }
      var filtered = _items.filter(function (item) {
        return (item.title || '').toLowerCase().indexOf(q) !== -1 ||
               (item.offer_id || '').toLowerCase().indexOf(q) !== -1;
      });
      renderList(filtered);
    });
  }

  function init() { initSearch(); initCompare(); }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // 退出登录时清空历史页，回到未登录态（避免残留上一个账号的数据）
  function reset() {
    _items = [];
    _selected = {};
    var els = getEls();
    if (els.search) els.search.value = '';
    if (els.list) {
      els.list.innerHTML = '<div class="empty-state"><div class="empty-icon">🔐</div><p>' +
        (I18N.t('history.loginRequired') || '登录后查看历史记录') + '</p></div>';
    }
    if (els.counter) els.counter.style.display = 'none';
    var bar = document.getElementById('compareBar');
    if (bar) bar.style.display = 'none';
    var modal = document.getElementById('compareModal');
    if (modal) modal.style.display = 'none';
  }

  return { load: load, renderList: renderList, reset: reset };
})();
